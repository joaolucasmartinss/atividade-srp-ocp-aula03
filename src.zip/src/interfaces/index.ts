export interface Trabalhavel {
  trabalhar(): void;
}
export interface RegistraPonto {
  registrarPonto(): void;
}
export interface Assalariado {
  receberSalario(): void;
}
export interface Gerenciavel {
  gerenciarEquipe(): void;
}
export interface Programavel {
  escreverCodigo(): void;
}
export interface Remuneravel {
  receberPagamento(): void;
}
