import { Trabalhavel, RegistraPonto, Programavel, Remuneravel } from "../interfaces";

export class Estagiario implements Trabalhavel, RegistraPonto, Programavel, Remuneravel {
  trabalhar(): void { console.log("Estagiário trabalhando"); }
  registrarPonto(): void { console.log("Ponto registrado"); }
  receberBolsa(): void { console.log("Bolsa recebida"); }
  escreverCodigo(): void { console.log("Estagiário escrevendo código"); }
  receberPagamento(): void { this.receberBolsa(); }
}
