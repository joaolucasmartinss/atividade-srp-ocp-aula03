import { Trabalhavel, RegistraPonto, Assalariado, Gerenciavel, Remuneravel } from "../interfaces";

export class Gerente implements Trabalhavel, RegistraPonto, Assalariado, Gerenciavel, Remuneravel {
  trabalhar(): void { console.log("Gerente trabalhando"); }
  registrarPonto(): void { console.log("Ponto registrado"); }
  receberSalario(): void { console.log("Salário recebido"); }
  gerenciarEquipe(): void { console.log("Gerenciando equipe"); }
  receberPagamento(): void { this.receberSalario(); }
}
