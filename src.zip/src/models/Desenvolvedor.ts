import { Trabalhavel, RegistraPonto, Assalariado, Programavel, Remuneravel } from "../interfaces";

export class Desenvolvedor implements Trabalhavel, RegistraPonto, Assalariado, Programavel, Remuneravel {
  trabalhar(): void { console.log("Desenvolvedor trabalhando"); }
  registrarPonto(): void { console.log("Ponto registrado"); }
  receberSalario(): void { console.log("Salário recebido"); }
  escreverCodigo(): void { console.log("Escrevendo código"); }
  receberPagamento(): void { this.receberSalario(); }
}
