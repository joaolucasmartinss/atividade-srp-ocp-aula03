import { Trabalhavel, Programavel, Remuneravel } from "../interfaces";

export class Freelancer implements Trabalhavel, Programavel, Remuneravel {
  trabalhar(): void { console.log("Freelancer trabalhando"); }
  escreverCodigo(): void { console.log("Freelancer escrevendo código"); }
  receberPorProjeto(): void { console.log("Pagamento por projeto recebido"); }
  receberPagamento(): void { this.receberPorProjeto(); }
}
