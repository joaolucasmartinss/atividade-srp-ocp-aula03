import { Gerente } from "./models/Gerente";
import { Desenvolvedor } from "./models/Desenvolvedor";
import { Estagiario } from "./models/Estagiario";
import { Freelancer } from "./models/Freelancer";
import { SistemaRH } from "./services/SistemaRH";
import { Trabalhavel, Remuneravel } from "./interfaces";

const gerente = new Gerente();
const dev = new Desenvolvedor();
const estagiario = new Estagiario();
const freelancer = new Freelancer();

const sistema = new SistemaRH(
  [gerente, dev, estagiario, freelancer] as Trabalhavel[],
  [gerente, dev, estagiario, freelancer] as Remuneravel[]
);

sistema.executarJornada();
sistema.processarPagamentos();
