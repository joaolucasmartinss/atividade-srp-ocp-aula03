import { Trabalhavel, Remuneravel } from "../interfaces";

export class SistemaRH {
  private funcionarios: Remuneravel[];
  private trabalhadores: Trabalhavel[];

  constructor(trabalhadores: Trabalhavel[], funcionarios: Remuneravel[]) {
    this.trabalhadores = trabalhadores;
    this.funcionarios = funcionarios;
  }

  executarJornada(): void {
    console.log("\n--- Iniciando jornada ---");
    this.trabalhadores.forEach(t => t.trabalhar());
  }

  processarPagamentos(): void {
    console.log("\n--- Processando pagamentos ---");
    this.funcionarios.forEach(f => f.receberPagamento());
  }
}
